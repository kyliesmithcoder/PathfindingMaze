﻿// System.Time.js
//////////////////////////////////////////////////////////////////////////////////////////////

// TimeBehavior : A system for measuring a series of time samples.
function TimeBehavior(maxSamples) {
    this.samples = [];
    this.stopWatch = null;
    this.maxSamples = maxSamples;
}

// Sleep : Delay for amount many milliseconds
function Sleep(amount) {
    var currentTime = _GetClock();
    var endTime = currentTime + amount;
    while (true) {
        currentTime = _GetClock();
        if (currentTime >= endTime) return;
    }
}

// _RangeMap : Maps value from the range [min1,max1] ==> [min2,max2]
function _RangeMap(value, min1, max1, min2, max2) {
    return min2 + (value - min1) / (max1 - min1) * (max2 - min2);
}

// TimeBehavior.RenderTimeBehavior : Plot a graph of the current time behavior
TimeBehavior.prototype.RenderTimeBehavior = function (x, y, w, h, color) {
    if (color == undefined) color = "Black";
    // Draw solid background box
    _DrawSolidBox(x, y, w, h, "rgb(200, 200, 200)");
    // Draw hollow framing box
    _DrawHollowBox(x, y, w, h, "rgb(127, 127, 127)");
    // Let biggest = 0
    var biggest = 0;
    // For each sample, if sample.value > biggest, then biggest = sample.value
    for (var n = 0; n < this.samples.length; n++) {
        var sample = this.samples[n];
        if (sample.deltaTime > biggest) {
            biggest = sample.deltaTime;
        }
    }
    draw.strokeStyle = color;
    draw.beginPath();
    draw.moveTo(x, y);
    // For each sample,
    for (var n = 0; n < this.samples.length; n++) {
        // Let N be the sample value (that is ~ the Y position)
        var sample = this.samples[n];
        // Plot Y:  [0, biggest] ==> [y+h, y]
        var Y = _RangeMap(sample.deltaTime, 0, biggest, y + h, y);
        // Plot X:  [0, N-1] ==> [x, x+w]
        var X = _RangeMap(n, 0, this.samples.length - 1, x, x + w);
        // Plot the point (X, Y)
        draw.lineTo(X, Y);
    }
    draw.stroke();
}

// TimeBehavior.StartSample : A function to start measurement of a time sample.
TimeBehavior.prototype.StartSample = function () {
    this.stopWatch = new StopWatch();
    this.stopWatch.Start();
}

// TimeBehavior.EndSample : A function to end measurement of a time sample.
TimeBehavior.prototype.EndSample = function () {
    this.stopWatch.Stop();
    this.samples.push(this.stopWatch);
    this.stopWatch = null;
    // Check if there's too many samples
    while (this.samples.length > this.maxSamples) {
        // Chop off the sample(s) at the beginning
        this.samples.splice(0, 1);
    }
}

// StopWatch : An object for measuring time differences.
function StopWatch() {
    this.startTime = 0;
    this.endTime = 0;
    this.deltaTime = 0;
}

// StopWatch.Start : A function to start the stop watch.
StopWatch.prototype.Start = function () {
    this.startTime = _GetClock();
}

// StopWatch.Stop : A function to end the stop watch.
StopWatch.prototype.Stop = function () {
    this.endTime = _GetClock();
    this.deltaTime = this.endTime - this.startTime;
}

// _GetClock : Read current time in milliseconds.
function _GetClock() {
    var timeNow = new Date();
    return timeNow.getTime();
}

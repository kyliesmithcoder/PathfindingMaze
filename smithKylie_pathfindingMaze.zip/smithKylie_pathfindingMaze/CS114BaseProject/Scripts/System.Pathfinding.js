﻿// System.Pathfinding.js
////////////////////////////////////////////////////////////////////////////////////

function _CreateExampleGraph() {
    var node1 = _CreateNode("node1", 60, 60);
    var node2 = _CreateNode("node2", 54, 53);
    var node3 = _CreateNode("node3", 238, 50);
    var node4 = _CreateNode("node4", 306, 53);
    var node5 = _CreateNode("node5", 382, 53);
    var node6 = _CreateNode("node6", 490, 54);
    var node7 = _CreateNode("node7", 604, 54);
    var node8 = _CreateNode("node8", 671, 52);
    var node9 = _CreateNode("node9", 125, 124);
    var node10 = _CreateNode("node10", 204, 123);
    var node11 = _CreateNode("node11", 237, 120);
    var node12 = _CreateNode("node12", 380, 139);
    var node13 = _CreateNode("node13", 418, 140);
    var node14 = _CreateNode("node14", 528, 140);
    var node15 = _CreateNode("node15", 673, 194);
    var node16 = _CreateNode("node16", 600, 195);
    var node17 = _CreateNode("node17", 529, 214);
    var node18 = _CreateNode("node18", 415, 213);
    var node19 = _CreateNode("node19", 344, 213);
    var node20 = _CreateNode("node20", 306, 213);
    var node21 = _CreateNode("node21", 234, 212);
    var node22 = _CreateNode("node22", 199, 211);
    var node23 = _CreateNode("node23", 130, 210);
    var node24 = _CreateNode("node24", 55, 214);
    var node25 = _CreateNode("node25", 50, 336);
    var node26 = _CreateNode("node26", 201, 285);
    var node27 = _CreateNode("node27", 345, 283);
    var node28 = _CreateNode("node28", 421, 283);
    var node29 = _CreateNode("node29", 529, 283);
    var node30 = _CreateNode("node30", 673, 354);
    var node31 = _CreateNode("node31", 601, 354);
    var node32 = _CreateNode("node32", 455, 354);
    var node33 = _CreateNode("node33", 420, 353);
    var node34 = _CreateNode("node34", 344, 355);
    var node35 = _CreateNode("node35", 273, 353);
    var node36 = _CreateNode("node36", 200, 353);
    var node37 = _CreateNode("node37", 54, 406);
    var node38 = _CreateNode("node38", 127, 405);
    var node39 = _CreateNode("node39", 346, 425);
    var node40 = _CreateNode("node40", 383, 426);
    var node41 = _CreateNode("node41", 55, 478);
    var node42 = _CreateNode("node42", 200, 479);
    var node43 = _CreateNode("node43", 272, 479);
    var node44 = _CreateNode("node44", 346, 480);
    var node45 = _CreateNode("node45", 382, 479);
    var node46 = _CreateNode("node46", 456, 478);
    var node47 = _CreateNode("node47", 529, 478);
    var node48 = _CreateNode("node48", 601, 478);
    var node49 = _CreateNode("node49", 674, 480);

    _ConnectNodes(node2, node3, true);
    _ConnectNodes(node3, node4, true);
    _ConnectNodes(node4, node5, true);
    _ConnectNodes(node5, node6, true);
    _ConnectNodes(node6, node7, true);
    _ConnectNodes(node7, node8, true);
    _ConnectNodes(node8, node15, true);
    _ConnectNodes(node14, node13, true);
    _ConnectNodes(node13, node12, true);
    _ConnectNodes(node11, node10, true);
    _ConnectNodes(node10, node9, true);
    _ConnectNodes(node24, node23, true);
    _ConnectNodes(node22, node21, true);
    _ConnectNodes(node20, node19, true);
    _ConnectNodes(node18, node17, true);
    _ConnectNodes(node29, node28, true);
    _ConnectNodes(node27, node26, true);
    _ConnectNodes(node36, node35, true);
    _ConnectNodes(node35, node34, true);
    _ConnectNodes(node33, node32, true);
    _ConnectNodes(node37, node38, true);
    _ConnectNodes(node41, node42, true);
    _ConnectNodes(node43, node44, true);
    _ConnectNodes(node44, node45, true);
    _ConnectNodes(node39, node40, true);
    _ConnectNodes(node45, node46, true);
    _ConnectNodes(node46, node47, true);
    _ConnectNodes(node47, node48, true);
    _ConnectNodes(node48, node49, true);
    _ConnectNodes(node15, node30, true);
    _ConnectNodes(node30, node49, true);
    _ConnectNodes(node31, node48, true);
    _ConnectNodes(node16, node31, true);
    _ConnectNodes(node7, node16, true);
    _ConnectNodes(node14, node17, true);
    _ConnectNodes(node17, node29, true);
    _ConnectNodes(node29, node47, true);
    _ConnectNodes(node32, node46, true);
    _ConnectNodes(node28, node33, true);
    _ConnectNodes(node40, node45, true);
    _ConnectNodes(node39, node44, true);
    _ConnectNodes(node35, node43, true);
    _ConnectNodes(node36, node42, true);
    _ConnectNodes(node37, node41, true);
    _ConnectNodes(node24, node25, true);
    _ConnectNodes(node23, node38, true);
    _ConnectNodes(node22, node26, true);
    _ConnectNodes(node19, node27, true);
    _ConnectNodes(node17, node29, true);
    _ConnectNodes(node14, node17, true);
    _ConnectNodes(node13, node18, true);
    _ConnectNodes(node4, node20, true);
    _ConnectNodes(node11, node21, true);
    _ConnectNodes(node10, node22, true);
    _ConnectNodes(node9, node23, true);
    _ConnectNodes(node1, node24, true);
    _ConnectNodes(node5, node12, true);
    _ConnectNodes(node27, node34, true);
    _ConnectNodes(node3, node11, true);

    // Plot a route through the maze
    _StartNode = NODES[0];
    _EndNode = NODES[NODES.length - 1];
    _PlotRoute(_StartNode, _EndNode);

    // Set position of mouse and cheese
    _MouseX = _StartNode.x;
    _MouseY = _StartNode.y;
    _CheeseX = _EndNode.x;
    _CheeseY = _EndNode.y;
}

function _DrawMazeProject() {

    _ClearScreen();

    if (STATE == 0) {
        // Pick random spot for the cheese
        var index = Math.floor(Math.random() * (NODES.length - 1));
        _EndNode = NODES[index];
        _CheeseX = _EndNode.x;
        _CheeseY = _EndNode.y;
        _PlotRoute(_StartNode, _EndNode);
        STATE = 1;
        // Select the next node for the mouse
        _TargetNode = 0;
    }
    if (STATE == 1) {
        // Walk the mouse towards the next node of the graph
        var node = _EndNode.Path[_TargetNode];
        var vx = node.x - _MouseX;
        var vy = node.y - _MouseY;
        var length = Math.sqrt(vx * vx + vy * vy);
        if (length > 0) {
            vx /= length;
            vy /= length;
            vx *= 2;
            vy *= 2;
            _MouseX += vx;
            _MouseY += vy;
        }
        // If it has gotten there, pick its next node in the path
        if (length < 10) {
            _TargetNode += 1;
            if (_TargetNode >= _EndNode.Path.length) {
                // Gotten to the last node
                STATE = 0;
                _StartNode = _EndNode;
            }
        }
    }

    _DrawImage("./Images/maze.png", 0, 0, 728, 532);
    //_DrawGraph(NODES);

    // Draw the path to the end node
    //_DrawPath(_EndNode);

    // Draw the mouse
    _DrawImage("./Images/Mouse.png", _MouseX - 32 / 2, _MouseY - 48 / 2);
    // Draw the cheese
    _DrawImage("./Images/Cheese.png", _CheeseX - 36 / 2, _CheeseY - 35 / 2);
}


var NODE_WIDTH = 20;
var NODE_HEIGHT = 20;
var _INFINITY_ = 9999.0;

var STATE = 0;
var _TargetNode = 0;
var _MouseX = 0;
var _MouseY = 0;
var _CheeseX = 0;
var _CheeseY = 0;

// Array of nodes
var NODES = [];
var _StartNode = null;
var _EndNode = null;

// Utility Functions
function _CreateNode(name, x, y) {
    var node = new Node(name, x, y);
    NODES.push(node);
    return node;
}

var _WORKING_SET = [];
// _CopyPath : Copies the path from node1 and overwrites node2's path
function _CopyPath(node2, node1) {
    node2.Path = [];
    for (var n = 0; n < node1.Path.length; n++) {
        node2.Path.push(node1.Path[n]);
    }
}
function _IsNodeInSet(WS, node1) {
    for (var n = 0; n < WS.length; n++) {
        var node2 = WS[n];
        if (node1.name === node2.name) return true;
    }
    return false;
}
function _PlotRoute(start, end) {
    // Reset pathfinding machine
    for (var n = 0; n < NODES.length; n++) {
        var node = NODES[n];
        node.Path = [];
        node.PathLength = _INFINITY_;
        node.Sealed = false;
    }

    // Set the path length of the starting node to 0
    start.PathLength = 0;
    start.Path.push(start);

    // Clear the working set
    _WORKING_SET = [];

    // Append the start node to the working set
    _WORKING_SET.push(start);

    // While the ending node is not sealed...
    while (end.Sealed == false) {
        // For every node in the working set which is not sealed
        for (var n = 0; n < _WORKING_SET.length; n++) {
            var node1 = _WORKING_SET[n];
            if (node1.Sealed == true) continue;
            // For each node adjacent to this one, which isn't sealed...
            for (var m = 0; m < node1.outboundEdges.length; m++) {
                // Let E be the edge from node1 to node2
                var edge = node1.outboundEdges[m];
                var node2 = edge.outboundNode;
                if (node2.Sealed == true) continue;
                // Ignore the node if it is going to itself
                if (node1.name === node2.name) continue;
                // Add the node to the working set
                if (_IsNodeInSet(_WORKING_SET, node2) == false) {
                    _WORKING_SET.push(node2);
                }
                // If the path from node1 along this edge to node2, has a
                // shorter length than what's on node2, overwrite node2's path.
                if (node1.PathLength + edge.value < node2.PathLength) {
                    // Copy the path from node1, onto node2
                    _CopyPath(node2, node1);
                    // Append this edge to that path
                    node2.Path.push(node2);
                    // Set the path length on node 2
                    node2.PathLength = node1.PathLength + edge.value;
                }
            }
            // Seal off this node, if all its adjacencies have paths
            var bAllHavePaths = true;
            for (var m = 0; m < node1.outboundEdges.length; m++) {
                // Get the adjacency node
                var edge = node1.outboundEdges[m];
                var node2 = edge.outboundNode;
                if (node2.Path.length == 0) {
                    bAllHavePaths = false;
                }
            }
            if (bAllHavePaths == true) {
                node1.Sealed = true;
            }
            // If the path length on the ending node is less than Infinity
            // then seal off the ending node...
            if (end.PathLength < _INFINITY_) {
                end.Sealed = true;
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////

function _DrawNodeLine(node1, node2, lineThickness) {
    if (lineThickness == undefined) {
        lineThickness = 1;
    }
    draw.lineStyle = "Black";
    draw.lineWidth = lineThickness;
    draw.beginPath();
    draw.moveTo(node1.x, node1.y);
    draw.lineTo(node2.x, node2.y);
    draw.stroke();
}

function _DrawGraph(nodes) {
    for (var n = 0; n < nodes.length; n++) {
        var node = nodes[n];
        for (var m = 0; m < node.outboundEdges.length; m++) {
            var edge = node.outboundEdges[m];
            _DrawNodeLine(node, edge.outboundNode);
        }
    }
    for (var n = 0; n < nodes.length; n++) {
        var node = nodes[n];
        _DrawImage("./Images/NodeStyle2.png", node.x - NODE_WIDTH / 2, node.y - NODE_HEIGHT / 2);
    }
}

function _DrawPath(endNode) {
    for (var n = 0; n < endNode.Path.length - 1; n++) {
        var node1 = endNode.Path[n];
        var node2 = endNode.Path[n + 1];
        _DrawNodeLine(node1, node2, 3);
    }
}

﻿// StudentCode.CORE.js
//////////////////////////////////////////////////////////////////////////////////////////


var STATE = 0;

var View_x = 0;
var View_y = 0;

var Char_x = 0;
var Char_y = 0;
var Chz_x = 0;
var Chz_y = 0;

var _StartNode = null;
var _EndNode = null;
var _TargetNodeIndex = 0;
var NODES = [];

var _WORKING_SET = [];
var _INFINITY_ = 9999.0;


// PathFinding Functions
////////////////////////////////////////////////////////////

function Node(name, x, y) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.outboundEdges = [];
    this.inboundEdges = [];
    this.Path = [];
    this.PathLength = _INFINITY_;
    this.Sealed = false;
}

function _CreateNode(name, x, y) {
    var node = new Node(name, x, y);
    NODES.push(node);
    return node;
}

function Edge() {
    this.value = 0;
    this.inboundNode = null;
    this.outboundNode = null;
}

function _ConnectNodes(node1, node2, bidirectional) {

    if (bidirectional == undefined) {
        bidirectional = false;
    }
    var edge1 = new Edge();
    var edge2 = new Edge();
    edge1.inboundNode = node1;
    edge1.outboundNode = node2;
    node1.outboundEdges.push(edge1);
    node2.inboundEdges.push(edge1);
    if (bidirectional) {
        edge2.inboundNode = node2;
        edge2.outboundNode = node1;
        node1.inboundEdges.push(edge2);
        node2.outboundEdges.push(edge2);
    }
    var Vx = node1.x - node2.x;
    var Vy = node1.y - node2.y;
    var dist = Math.sqrt(Vx * Vx + Vy * Vy);
    edge1.value = dist;
    if (bidirectional) {
        edge2.value = dist;
    }

}

function _IsNodeInSet(_WORKING_SET, nodeA) {

    for (var n = 0; n < _WORKING_SET.length; n++) {
        var nodeB = _WORKING_SET[n];
        if (nodeA.name === nodeB.name) return true;
    }
    return false;

}

function _CopyPath(nodeB, nodeA) {

    nodeB.Path = [];
    for (var n = 0; n < nodeA.Path.length; n++) {
        nodeB.Path.push(nodeA.Path[n]);
    }

}

function _PlotRoute(start, end) {

    for (var n = 0; n < NODES.length; n++) {
        var node = NODES[n];
        node.Path = [];
        node.PathLength = _INFINITY_;
        node.Sealed = false;
    }

    start.PathLength = 0;
    start.Path.push(start);

    _WORKING_SET = [];
    _WORKING_SET.push(start);

    while (end.Sealed == false) {
        for (var n = 0; n < _WORKING_SET.length; n++) {
            var nodeA = _WORKING_SET[n];
            if (nodeA.Sealed == true) continue;
            //var shouldSealNode = true;
            for (var m = 0; m < nodeA.outboundEdges.length; m++) {
                var edge = nodeA.outboundEdges[m];
                var nodeB = edge.outboundNode;
                //if (nodeB.PathLength == 0) shouldSealNode = false;
                if (nodeB.Sealed == true) continue;
                if (nodeA.name === nodeB.name) continue;
                if (_IsNodeInSet(_WORKING_SET, nodeB) == false) {
                    _WORKING_SET.push(nodeB);
                }
                if (nodeA.PathLength + edge.value < nodeB.PathLength) {
                    _CopyPath(nodeB, nodeA);
                    nodeB.Path.push(nodeB);
                    nodeB.PathLength = nodeA.PathLength + edge.value;
                }
            }
            var bAllHavePaths = true;
            for (var m = 0; m < nodeA.outboundEdges.length; m++) {
                var edge = nodeA.outboundEdges[m];
                var nodeB = edge.outboundNode;
                if (nodeB.Path.length == 0) {
                    bAllHavePaths = false;
                }
            }
            if (bAllHavePaths == true) {
                nodeA.Sealed = true;
            }
            if (end.PathLength < _INFINITY_) {
                end.Sealed = true;
            }
        }
    }

}

function _OnCharacterSelectTarget() {

    var index = Math.floor(Math.random() * (NODES.length - 1));

    _EndNode = NODES[index];

    Chz_x = _EndNode.x;
    Chz_y = _EndNode.y;

    _PlotRoute(_StartNode, _EndNode);

    STATE = 1;
    _TargetNodeIndex = 0;

}

function _OnCharacterChaseTarget() {

    var node = _EndNode.Path[_TargetNodeIndex];
    var vx = node.x - Char_x;
    var vy = node.y - Char_y;
    var dist = Math.sqrt(vx * vx + vy * vy);
    if (dist > 0) {
        vx /= dist;
        vy /= dist;
        vx *= 2;
        vy *= 2;
        Char_x += vx;
        Char_y += vy;
    }
    if (dist < 10) {
        _TargetNodeIndex += 1;

        if (_TargetNodeIndex >= _EndNode.Path.length) {
            STATE = 0;
            _StartNode = _EndNode;
        }
    }

}
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////


function OnInitialize() {
    
    NodeConnections();

    _StartNode = NODES[0];
    _EndNode = NODES[NODES.length - 1];
    _PlotRoute(_StartNode, _EndNode);

    Char_x = _StartNode.x;
    Char_y = _StartNode.y;
    Chz_x = _EndNode.x;
    Chz_y = _EndNode.y;

}

function OnFrame() {

    _ClearScreen();

    View_x = View_x + 0.02 * ((Char_x - 300) - View_x);
    View_y = View_y + 0.02 * ((Char_y - 300) - View_y);

    if (STATE == 0) {
        _OnCharacterSelectTarget();
    }
    if (STATE == 1) {
        _OnCharacterChaseTarget();
    }

    _DrawImage("./Images/mazeLayout.png", 0 - View_x, 0 - View_y);
    _DrawImage("./Images/character_sacrier.png", Char_x - (30.0 / 2.0) - View_x, Char_y - (64.0) - View_y);
    _DrawImage("./Images/default_cheese.png", Chz_x - (36.0 / 2.0) - View_x, Chz_y - (35.0 / 2.0) - View_y);

    if (View_x < 0) {
        View_x = 0;
    }
    if (View_x > 290) {
        View_x = 290;
    }
    if (View_y < 0) {
        View_y = 0;
    }
    if (View_y > 490) {
        View_y = 490;
    }

}

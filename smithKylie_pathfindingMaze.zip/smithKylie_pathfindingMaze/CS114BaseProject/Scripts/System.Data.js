﻿// System.Data.js
/////////////////////////////////////////////////////////////////////////////////

//var stack = new Stack();
//stack.Push(12);
//stack.Push(14);
//var n = stack.Pop();

function Stack() {
    this.items = [];
}

Stack.prototype.Push = function (item) {
    this.items.push(item);
}

Stack.prototype.Pop = function () {
    return this.items.pop();
}

/////////////////////////////////////////////////////////////////////////////////

// var queue = new Queue();
// queue.ShiftIn("Bob");
// queue.ShiftIn("Steve");
// queue.ShiftIn("Harvey");
// var person = queue.ShiftOut();

function Queue() {
    this.items = [];
}

Queue.prototype.ShiftIn = function (item) {
    this.items.unshift(item);
}

Queue.prototype.ShiftOut = function () {
    return this.items.pop();
}

/////////////////////////////////////////////////////////////////////////////////

function PriorityQueueItem(data, priority) {
    this.data = data;
    this.priority = priority;
}

function PriorityQueue() {
    this.items = [];
}

PriorityQueue.prototype.ShiftIn = function (data, priority) {
    var item1 = new PriorityQueueItem(data, priority);
    if (this.items.length < 1) {
        this.items.unshift(item1);
        return;
    }
    for (var n = 0; n < this.items.length; n++) {
        var item2 = this.items[n];
        if (item1.priority > item2.priority) {
            this.items.splice(n, 0, item1);
            return;
        }
    }
    // If the item wasn't added in by priority in the earlier
    // steps, then just put it at the end of the queue.
    this.items.push(item1);
}

PriorityQueue.prototype.ShiftOut = function () {
    var item = this.items.shift();
    return item.data;
}

//////////////////////////////////////////////////////////////////////////////////

function CircularBuffer(size) {
    this.items = [];
    this.size = size;
}

CircularBuffer.prototype.SetSize = function (size) {
    this.size = size;
}

CircularBuffer.prototype.AddItem = function (item) {
    this.items.push(item);
    while (this.items.length > this.size) {
        this.items.shift();
    }
}

CircularBuffer.prototype.GetItem = function (position) {
    if (position < 0) return null;
    if (position >= this.items.length) return null;
    return this.items[position];
}

///////////////////////////////////////////////////////////////////////////////////

function List() {
    this.items = [];
}

List.prototype.Append = function (item) {
    this.items.push(item);
}

List.prototype.Prepend = function (item) {
    this.items.unshift(item);
}

List.prototype.Insert = function (item, position) {
    if (position < 0) position = 0;
    if (position > this.items.length - 1) position = this.items.length - 1;
    this.items.splice(position, 0, item);
}

List.prototype.Remove = function (position) {
    return this.items.splice(position, 1);
}

List.prototype.GetItem = function (position) {
    if (position < 0) return null;
    if (position >= this.items.length) return null;
    return this.items[position];
}

List.prototype.Sort = function (compareFunction) {
    this.items.sort(compareFunction);
}

/////////////////////////////////////////////////////////////////////////////////

function Hashtable() {
    this.items = [];
}

Hashtable.prototype.GetItem = function (key) {
    return this.items[key];
}

Hashtable.prototype.SetItem = function (key, item) {
    this.items[key] = item;
}

Hashtable.prototype.RemoveItem = function (key) {
    delete this.items[key];
}

/////////////////////////////////////////////////////////////////////////////////

function BinaryTreeNode(data) {
    if (data == undefined) data = null;
    this.left = null;
    this.right = null;
    this.data = data;
}

BinaryTreeNode.prototype.SetLeft = function (node) {
    this.left = node;
}

BinaryTreeNode.prototype.SetRight = function (node) {
    this.right = node;
}

BinaryTreeNode.prototype.Insert = function (data, compareFunction) {
    if (this.data == null) {
        this.data = data;
        return;
    }
    var result = compareFunction(data, this.data);
    if (result == -1) {
        if (this.left != null) {
            this.left.Insert(data, compareFunction);
        } else {
            this.left = new BinaryTreeNode(data);
        }
    } else if (result == 1) {
        if (this.right != null) {
            this.right.Insert(data, compareFunction);
        } else {
            this.right = new BinaryTreeNode(data);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////

// Definition of node
function Node(name, x, y) {
    this.name = name;
    this.x = x;
    this.y = y;
    // Edges
    this.outboundEdges = [];
    this.inboundEdges = [];
    // Dijkstra's Algorithm Variables
    this.Path = [];
    this.PathLength = 99999;
    this.Sealed = false;
}

function Edge() {
    this.value = 0;
    this.inboundNode = null;
    this.outboundNode = null;
}

function _ConnectNodes(node1, node2, bidirectional) {
    if (bidirectional == undefined) {
        bidirectional = false;
    }
    var edge1 = new Edge();
    var edge2 = new Edge();
    edge1.inboundNode = node1;
    edge1.outboundNode = node2;
    node1.outboundEdges.push(edge1);
    node2.inboundEdges.push(edge1);
    if (bidirectional) {
        edge2.inboundNode = node2;
        edge2.outboundNode = node1;
        node1.inboundEdges.push(edge2);
        node2.outboundEdges.push(edge2);
    }
    // Calculate and store edge information
    var Vx = node1.x - node2.x;
    var Vy = node1.y - node2.y;
    var dist = Math.sqrt(Vx * Vx + Vy * Vy);
    edge1.value = dist;
    if (bidirectional) {
        edge2.value = dist;
    }
}




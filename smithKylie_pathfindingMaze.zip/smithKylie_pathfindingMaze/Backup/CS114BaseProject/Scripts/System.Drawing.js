////////////////////////////////////////////////////////
// System.Drawing.js

var _pixel_width = 1;
var _pixel_height = 1;

function _SetColor(color) {
    draw.fillStyle = color;
}

function _SetAlpha(alpha) {
    if (alpha > 1.0) alpha = 1.0;
    if (alpha < 0.0) alpha = 0.0;
    draw.globalAlpha = alpha;
}

function _GetAlpha() {
    return draw.globalAlpha;
}

function _CreateColor(r, g, b) {

    r = Math.floor(r);
    g = Math.floor(g);
    b = Math.floor(b);

    if (r < 0) r = 0;
    if (r > 255) r = 255;
    if (g < 0) g = 0;
    if (g > 255) g = 255;
    if (b < 0) b = 0;
    if (b > 255) b = 255;

    return "rgb(" + r + "," + g + "," + b + ")";

}

function _SetPixelSize(w, h) {
    _pixel_width = w;
    _pixel_height = h;
}

function _PutPixel(x, y) {

    draw.fillRect(_pixel_width * x, _pixel_height * y, _pixel_width, _pixel_height);

}

function PixelRGBA() {
    this.r = 0.0;
    this.g = 0.0;
    this.b = 0.0;
    this.a = 0.0;
}

function _GetPixel(x, y) {
    var color = new PixelRGBA();
    var imgd = draw.getImageData(x, y, 1, 1);
    var pix = imgd.data;
    color.r = pix[0];
    color.g = pix[1];
    color.b = pix[2];
    color.a = pix[3];
    return color;
}

function _DrawRectangle(x1, y1, w, h) {
    draw.fillRect(x1, y1, w, h);
}

function _FillScreen() {
    draw.fillRect(0, 0, canvas.width, canvas.height);
}

function _EraseRectangle(x1, y1, w, h) {
    draw.clearRect(x1, y1, w, h);
}

function _ClearScreen() {
    draw.clearRect(0, 0, canvas.width, canvas.height);
}

function _DrawText(text, x, y) {
    draw.fillText(text, x, y);
}

function _EraseCircle(cx, cy, radius) {
    draw.save();
    draw.beginPath();
    draw.arc(cx, cy, radius, 0, 2 * Math.PI);
    //draw.stroke();
    draw.clip();
    draw.clearRect(cx - radius, cy - radius, cx + radius, cy + radius);
    draw.restore();
}

function _DrawCircle(cx, cy, radius, color) {
    if (color == undefined) {
        color = "Red";
    }
    draw.beginPath();
    draw.arc(cx, cy, radius, 0, 2 * Math.PI);
    draw.stroke();
}

function _DrawLine(x1, y1, x2, y2, color, lineWidth) {
    if (lineWidth == undefined) {
        lineWidth = 1;
    }
    if (color == undefined) {
        color = "Red";
    }
    draw.strokeStyle = color;
    draw.lineWidth = lineWidth;
    draw.beginPath();
    draw.moveTo(x1, y1);
    draw.lineTo(x2, y2);
    draw.stroke();
}

function _DrawAngledBox(angle, cx, cy, radius_width, radius_height) {
    angle = angle * 2 * 3.14159265358 / 360;
    var x1 = cx - radius_width;
    var y1 = cy - radius_height;
    var x2 = cx + radius_width;
    var y2 = cy - radius_height;
    var x3 = cx + radius_width;
    var y3 = cy + radius_height;
    var x4 = cx - radius_width;
    var y4 = cy + radius_height;
    var pt1 = _RotatePoint(angle, x1, y1, cx, cy);
    var pt2 = _RotatePoint(angle, x2, y2, cx, cy);
    var pt3 = _RotatePoint(angle, x3, y3, cx, cy);
    var pt4 = _RotatePoint(angle, x4, y4, cx, cy);
    _DrawLine(pt1.x - VX, pt1.y - VY, pt2.x - VX, pt2.y - VY);
    _DrawLine(pt2.x - VX, pt2.y - VY, pt3.x - VX, pt3.y - VY);
    _DrawLine(pt3.x - VX, pt3.y - VY, pt4.x - VX, pt4.y - VY);
    _DrawLine(pt4.x - VX, pt4.y - VY, pt1.x - VX, pt1.y - VY);
}

function _DrawHollowBox(x1, y1, x2, y2, color) {
    if (color == undefined) {
        color = "Red";
    }
    draw.strokeStyle = color;
    draw.beginPath();
    draw.rect(x1, y1, x2, y2);
    draw.stroke();
}

function _DrawSolidBox(x1, y1, x2, y2, color) {
    if (color == undefined) {
        color = "Red";
    }
    draw.strokeStyle = color;
    draw.fillStyle = color;
    draw.beginPath();
    draw.rect(x1, y1, x2, y2);
    draw.fill();
}